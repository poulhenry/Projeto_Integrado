<?php $__env->startSection("content"); ?>
    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Usuário</h3>
                </div>

            </div>
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Usuario</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br/>
                            <form id="demo-form2" action="/admin/alterar/usuario/<?php echo e(Hashids::encode($usuario->id)); ?>" method="post"
                                  data-parsley-validate class="form-horizontal form-label-left">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Nome <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="first-name" name="nome" required="required"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->name); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">E-mail <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="email" id="email" name="email" required="required"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->email); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="estado">Estado <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="estado" name="estado" required="required"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->estado); ?>">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cidade">Cidade <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="cidade" name="cidade" required="required"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->cidade); ?>">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="bairro">Bairro <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="bairro" name="bairro" required="required"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->bairro); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cep">CEP <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="cep" name="cep" required="required"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->cep); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="endereco">Endereço <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="endereco" name="endereco" required="required"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->endereco); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="numero">Número <span
                                            class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="numero" name="numero" required="required"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->numero); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="complemento">Complemento
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="complemento" name="complemento"
                                               class="form-control col-md-7 col-xs-12" value="<?php echo e($usuario->complemento); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="senha">Senha
                                        <span class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="senha" name="senha"
                                               class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12">Status</label>
                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                        <div class="">
                                            <label>
                                                <input type="checkbox" name="status" class="js-switch" checked/>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                        <button class="btn btn-primary" type="button">Cancelar</button>
                                        <button class="btn btn-primary" type="reset">Limpar</button>
                                        <button type="submit" class="btn btn-success">Alterar</button>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
    <script>

        <?php if(!empty(session("ok"))): ?>
        new PNotify({
            title: 'Alteração Realizada com Sucesso.',
            text: '<?php echo e(session("ok")); ?>',
            type: 'success',
            styling: 'bootstrap3'
        });
        <?php endif; ?>

        <?php if(!empty(session("erro"))): ?>
        new PNotify({
            title: 'Falha ao executar a Alteração.',
            text: '<?php echo e(session("erro")); ?>',
            type: 'error',
            styling: 'bootstrap3'
        });
        <?php endif; ?>


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.form-layout", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>